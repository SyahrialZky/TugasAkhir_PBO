/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package nocompany.tugasakhir_pbo.pages;

/**
 *
 * @author Lenovo
 */
public class TugasAkhir_PBO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
